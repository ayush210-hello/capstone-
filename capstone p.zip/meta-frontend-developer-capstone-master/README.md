# Meta Front-End Developer Capstone

This is the Capstone Project of[ Meta Front-End Developer](https://www.coursera.org/professional-certificates/meta-front-end-developer) Course on Coursera.

![Meta Front-End Developer Certificate.](https://drive.google.com/uc?id=15n6WsH2fdtOumdt-MIob80y6-wOjUb2g)

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

Live URL: https://scisamir-little-lemon.vercel.app/


## Available Scripts

In the project directory, you can run:

### `npm install`

Installs project's dependencies

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.
